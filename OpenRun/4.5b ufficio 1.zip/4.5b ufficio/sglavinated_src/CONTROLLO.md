# Controllo automatico — 2026-10-18 21:56 (generato dallo script, non modificare)

## Modelli assegnati
- builder-developer: opencode/nemotron-3.5-super-vl-free
- capo: opencode/nemotron-3.5-super-vl-free
- designer: opencode/nemotron-3.5-super-vl-free
- developer-builder-junior: opencode/nemotron-3.5-super-vl-free

Distribuzione:
     4 opencode/nemotron-3.5-super-vl-free

## Errori ricorrenti (ultime 300 righe di ogni log agente)
- collaudatore: rate limit 0, permessi negati 2, file/cartella inesistente 0
- developer-builder-junior: rate limit 0, permessi negati 2, file/cartella inesistente 2
- sviluppatore: rate limit 0, permessi negati 10, file/cartella inesistente 0
  -> sviluppatore: usa solo percorsi relativi e solo le tue cartelle (AGENTS.md); non provare shell/cd.

## Memoria agenti (compattazione automatica)

## Workflow
- blocchi chiusi [x]: 17; in corso [~]: 4; da fare [ ]: 4
- agenti con lavoro aperto: developer-builder-junior builder-developer 
- decisioni aperte per Andrea: 0
- istruzione: in pausa non servono nuove richieste; riprendi dai blocchi [~] e chiudi i file lasciati a meta.
