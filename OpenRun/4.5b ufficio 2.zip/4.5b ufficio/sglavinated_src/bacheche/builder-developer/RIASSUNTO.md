# Riassunto builder-developer — 19/10 06:53 (turno 1)
P1 [~]: punti 1-3 e 5 fatti (Pad::A, freno B/Down, coast 0.995, OFFROAD_SLOW 0.99, colline, wrap zRel, caricamento .sglraw); punto 4 sprite veri player/traffico/show in capo a G1/Designer.
T1-RUN [x]: DEFAULT T1-Q1 soddisfatto (sh tools/gate_t1.sh e soak exit 0, replay 2x IDENTICO, ms/frame <= 20); risposta Andrea non registrata.
Misure: 6 percorsi GATE PERCORSO OK (lv_01..lv_06); soak ms/frame medio 0.185 max 0.518, smoke medio 0.177-0.184 max 0.263-0.366 (limite 20); speed@60=161.79.
Log: UFFICIO/Officina/Test area/gate_t1.log (exit 0 dichiarato).
Zero scritture in motore_nuovo/ e tools/ in questo turno; nessun test del Junior modificato.
Residuo: v91 Andrea su sglavinated_runner (Mac SDL2) e fps/temperatura Pi 400 (ANDREA_REVIEW T1-Q3/T1-Q8); G1 [ ] fuori scope T1.
